import selenium.common.exceptions
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import time


class PortugalEmbassySite:
    def __init__(self, proxies=None):
        # chromedriver.exe was downloaded from https://chromedriver.chromium.org/home and was put in current dir
#        self.driver = webdriver.Chrome("chromedriver")
        options = webdriver.ChromeOptions()
        options.add_experimental_option('excludeSwitches', ['enable-logging'])
        self.driver = webdriver.Chrome("chromedriver", options=options)
        self.proxies = proxies



    def click_btn(self, btn_id):
        while True:
            try:
                self.driver.find_element_by_id(btn_id).click()
                break
            except (selenium.common.exceptions.NoSuchElementException,
                    selenium.common.exceptions.ElementClickInterceptedException,
                    selenium.common.exceptions.ElementNotInteractableException,
                    selenium.common.exceptions.StaleElementReferenceException) as e:
                time.sleep(0.2)

    def select_option(self, menu_id, option_xpath):
        while True:
            try:
                dropdown=self.driver.find_element_by_id(menu_id)
                element=dropdown.find_element(By.XPATH, option_xpath)
                self.driver.execute_script("arguments[0].click();", element)
                break
            except (selenium.common.exceptions.NoSuchElementException,
                    selenium.common.exceptions.ElementClickInterceptedException) as e:
                time.sleep(0.2)

    def schedule_meeting(self, account_id, birth_date):
        # goto embassy site
        self.driver.get('https://agendamentosonline.mne.gov.pt')
        start = time.time()
        # self.driver.implicitly_wait(10) # seconds
        #element_present = EC.presence_of_element_located((By.ID, 'j_idt68'))
        #WebDriverWait(self.driver, 1).until(element_present)

        #accept cookies
        self.click_btn("j_idt68")

        #accept terms
        self.click_btn("j_idt61")

        # select English language
        self.select_option(menu_id="indexForm:langs_label", option_xpath='//*[@id="indexForm:langs_panel"]/div/ul/li[1]')

        #accept terms again
        self.click_btn("j_idt61")

        #click schedule an appointment
        self.click_btn("indexForm:j_idt29")

        # self.driver.implicitly_wait(10) # seconds for the schedule an appointment page
        element_present = EC.presence_of_element_located((By.ID, 'scheduleForm:tabViewId:ccnum'))
        WebDriverWait(self.driver, 10).until(element_present)

##        # find ID field and send the account_id itself to the input field
##        self.driver.find_element_by_id("scheduleForm:tabViewId:ccnum").send_keys(account_id)

        # find birth date field and send the birth_date itself to the input field
        self.driver.find_element_by_id("scheduleForm:tabViewId:dataNascimento_input").send_keys(birth_date)
        self.click_btn("scheduleForm:tabViewId:ccnum")

        # find ID field and send the account_id itself to the input field
        self.driver.find_element_by_id("scheduleForm:tabViewId:ccnum").send_keys(account_id)

        # Click Search button
        self.click_btn("scheduleForm:tabViewId:searchIcon")

        #Select Embassy  in Tel Aviv
        self.select_option(menu_id="scheduleForm:postcons_label",
                           option_xpath='//*[@id="scheduleForm:postcons_panel"]/div/ul/li[2]')

        # Select Category
        self.select_option(menu_id="scheduleForm:categato_label",
                           option_xpath='//*[@id="scheduleForm:categato_panel"]/div/ul/li[2]')

        # click Add Consolur Act button
        self.click_btn("scheduleForm:bAddAto")

        # Accept terms and conditions
        self.click_btn("scheduleForm:dataTableListaAtos:0:selCond")

        time.sleep(0.5)

        # Click Schedule button
        self.click_btn("scheduleForm:dataTableListaAtos:0:bCal")

        end = time.time()
        print('  time taken {:.2f} s'.format(end - start))

        # wait for browser to be closed by user
        while True:
            try:
                _ = self.driver.window_handles
                time.sleep(1)
            except selenium.common.exceptions.WebDriverException as e:
                print('User closed the browser')
                self.driver.quit()
                exit(0)

        # wait the ready state to be complete
#        WebDriverWait(driver=self.driver, timeout=10).until(
#            lambda x: x.execute_script("return document.readyState === 'complete'")
#        )

# only at work, else {}
#proxies = {"http": "http://genproxy:8080", "https": "http://genproxy:8080"}
proxies=None
browser = PortugalEmbassySite(proxies=proxies)
## test browser.schedule_meeting(account_id='9104790663', birth_date='10-10-1972')
# for Sapir
browser.schedule_meeting(account_id='9105113366', birth_date='06-07-1999')
